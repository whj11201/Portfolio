for (const section of document.querySelectorAll("[data-youtube]")) {
  if (!["http:", "https:"].includes(location.protocol)) continue;
  const button = section.querySelector("button");
  button.hidden = false;
  button.addEventListener("click", () => {
    const frame = document.createElement("iframe");
    frame.src = "https://www.youtube.com/embed/" + encodeURIComponent(section.dataset.youtube);
    frame.title = section.dataset.videoTitle;
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    frame.allow = "encrypted-media; picture-in-picture; fullscreen";
    frame.allowFullscreen = true;
    section.prepend(frame);
    button.hidden = true;
    frame.focus();
  }, { once: true });
}
