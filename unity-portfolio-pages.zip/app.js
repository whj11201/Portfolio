// 공개가 승인된 검증 자료만 추가합니다. 입력 예시는 README에 있습니다.
const projects = [
  {
    "track": "xr",
    "title": "암모니아 연료 선박 안전 시뮬레이션",
    "cover": "./assets/images/xr-pipe-flow.jpg",
    "cardTags": ["Unity 6","C#","Quest 3"],
    "detailsUrl": "./ship-safety.html",
    "period": "2025.04–12",
    "kind": "회사 프로젝트",
    "summary": "선박 설비와 안전 교육을 위한 VR 시뮬레이션.",
    "stack": [
      "Unity",
      "XR Interaction Toolkit",
      "Shader Graph",
      "Quest 3",
      "VIVE"
    ],
    "contribution": "컨트롤러 레이로 설비 정보를 탐색하는 UI, 조작 순서에 따른 상태 표시, 거리 기반 감지 UI를 구현했습니다. Shader Graph로 유체 표현과 선택 영역 강조를 만들고 정적 환경에 조명을 베이크했습니다.",
    "verification": "Notion 기록 기준 Quest 계열과 VIVE에서 체험을 테스트했습니다.",
    "version": "Unity 6000.0.62f1"
  },
  {
    "track": "game",
    "title": "실감형 학교 체험 및 한국어 교육",
    "cover": "./assets/images/school-language.jpg",
    "cardTags": ["Unity 6","C#","WebGL"],
    "detailsUrl": "./school-experience.html",
    "period": "2025.05–12",
    "kind": "회사 프로젝트",
    "summary": "외국인 초등학생이 한국 학교생활과 한국어를 체험하는 교육 게임.",
    "stack": [
      "Unity",
      "Unity Localization",
      "RenderTexture",
      "WebGL",
      "Android",
      "AWS"
    ],
    "contribution": "Unity Localization과 대화·선택창을 구현했습니다. 후처리, 페이드 전환, RenderTexture 거울을 연출하고 레벨의 콜라이더·이벤트 트리거와 오브젝트를 배치했습니다. WebGL용 셰이더와 정적 오브젝트 설정을 조정했습니다.",
    "verification": "Notion 기록 기준 Android APK와 AWS에 올린 WebGL 빌드를 확인했습니다.",
    "version": "Unity 6000.0.62f1"
  },
  {
    "track": "game",
    "title": "Damned Ritual",
    "detailsUrl": "./damned-ritual.html",
    "cover": "./assets/images/damned-ritual-1.jpg",
    "cardTags": ["Unity 2022.3.33f1","C#","후처리"],
    "period": "2024.07–11",
    "kind": "팀 프로젝트",
    "summary": "적의 추격을 피하고 의식을 저지하는 공포 게임.",
    "stack": [
      "Unity",
      "Post-processing"
    ],
    "contribution": "로딩 화면과 해상도 선택 UI, 적 NPC의 이동·공격·사망과 피격 경직, 레벨 디자인을 담당했습니다. 비네트와 후처리로 공간의 분위기를 조정했습니다.",
    "verification": "",
    "version": "Unity 2022.3.33f1"
  },
  {
    "track": "xr",
    "title": "좀비 생존 · MR 패스스루",
    "detailsUrl": "./mr-survival.html",
    "cover": "./assets/images/mr-survival-1.jpg",
    "cardTags": ["Unity 2021.3.20f1","C#","Quest 2"],
    "period": "2023.12",
    "kind": "팀 프로젝트",
    "summary": "Quest 2의 패스스루를 활용한 혼합현실 생존 체험.",
    "stack": [
      "Unity",
      "Quest 2",
      "Oculus Integration",
      "NavMesh"
    ],
    "contribution": "포털 연출 이후 적을 생성하고 NavMesh로 플레이어를 추적하게 했습니다. 충돌 횟수와 제한시간에 따라 재시작하거나 종료하도록 구성했습니다.",
    "verification": "",
    "version": "Unity 2021.3.20f1"
  },
  {
    "track": "xr",
    "title": "장사상륙작전",
    "detailsUrl": "./jangsa-vr.html",
    "cover": "./assets/images/jangsa-vr-1.jpg",
    "cardTags": ["Unity 2022.3.33f1","C#","Quest 2"],
    "period": "2023.07–11",
    "kind": "대학 팀 프로젝트",
    "summary": "장사상륙작전을 소재로 한 역사 교육 VR 콘텐츠.",
    "stack": [
      "Unity",
      "Quest 2",
      "Occlusion Culling"
    ],
    "contribution": "NPC AI, 파티클 연출, 배경 제작, 보조 조명과 오클루전 컬링 설정을 담당했습니다.",
    "verification": "Notion에 계원예술대 조형제 학과 최우수작 및 KUMA 전시 기록이 있습니다.",
    "version": "Unity 2022.3.33f1"
  },
  {
    "track": "xr",
    "title": "던져라 볼링핀볼공",
    "detailsUrl": "./kinect-ball.html",
    "cover": "./assets/images/kinect-ball-1.jpg",
    "cardTags": ["Unity","Azure Kinect"],
    "period": "2023.10",
    "kind": "팀 프로젝트",
    "summary": "Azure Kinect의 신체 추적으로 공을 던지는 체감형 게임.",
    "stack": [
      "Unity",
      "Azure Kinect"
    ],
    "contribution": "",
    "verification": "팀 구현은 손과 어깨의 위치를 입력으로 사용해 공 던지기 동작을 감지합니다. 개인 분담은 원문에 명시되지 않았습니다."
  },
  {
    "track": "xr",
    "title": "시의 집",
    "detailsUrl": "./house-of-poetry.html",
    "cover": "./assets/images/house-of-poetry-1.jpg",
    "cardTags": ["Unity","VR","JavaScript"],
    "period": "2023.03–06",
    "kind": "대학 팀 프로젝트",
    "summary": "계절별 공간에서 사물을 조작하며 시를 체험하는 VR 콘텐츠.",
    "stack": [
      "Unity",
      "VR",
      "JavaScript",
      "CSS"
    ],
    "contribution": "오브젝트 잡기, 전달 조건에 따른 장면 전환, 터레인·파티클·애니메이션과 소개 웹사이트를 담당했습니다.",
    "verification": "Notion에 국제 커뮤니케이션 공모전 대상 수상 기록이 있습니다."
  },
  {
    "track": "game",
    "title": "영혼탈출",
    "detailsUrl": "./soul-escape.html",
    "cover": "./assets/images/soul-escape-1.jpg",
    "cardTags": ["Unity 2022.3.3f1","C#"],
    "period": "2023.06–07",
    "kind": "팀 프로젝트",
    "summary": "장애물을 조작하고 추격을 피하는 스테이지형 게임.",
    "stack": [
      "Unity"
    ],
    "contribution": "게임 기능 프로그래밍, 파티클 연출, 배경 제작, 사운드 보조, 빌드를 담당했습니다.",
    "verification": "",
    "version": "Unity 2022.3.3f1"
  },
  {
    "track": "game",
    "title": "Tank Story",
    "detailsUrl": "./tank-story.html",
    "cover": "./assets/images/tank-story-1.jpg",
    "cardTags": ["Unity 2021.3.20f1","C#","Occlusion Culling"],
    "period": "2023.09–11",
    "kind": "개인 프로젝트",
    "summary": "조이스틱으로 조작하는 탱크 액션 게임.",
    "stack": [
      "Unity",
      "Occlusion Culling"
    ],
    "contribution": "조이스틱 이동과 적·보스의 추적, 피격 넉백을 구현했습니다. 파티클 충돌의 한계를 보완하기 위해 자식 오브젝트를 활용한 판정을 구성하고 스테이지에 오클루전 컬링을 적용했습니다.",
    "verification": "",
    "version": "Unity 2021.3.20f1"
  }
];

const role = document.querySelector("#role");
const category = document.querySelector("#category");
const stack = document.querySelector("#stack");
const results = document.querySelector("#results");
const trackGrid = document.querySelector("#tracks");
const engineering = document.querySelector("#engineering-tracks");

function element(tag, text) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  return node;
}

function renderProject(project) {
  if (project.cover && project.detailsUrl) {
    const card = element("article");
    card.className = "featured-card archive-card";
    const link = element("a");
    link.href = project.detailsUrl;
    const preview = element("div");
    preview.className = "project-preview";
    const img = element("img");
    Object.assign(img, { src: project.cover, alt: "", loading: "lazy", decoding: "async" });
    preview.append(img);
    const body = element("div");
    body.className = "featured-card-body";
    const meta = element("p", [project.kind, project.period].join(" · "));
    meta.className = "archive-meta";
    const tags = element("ul");
    tags.className = "project-tags";
    tags.setAttribute("aria-label", "기술 스택");
    for (const tag of project.cardTags) tags.append(element("li", tag));
    const action = element("span", "프로젝트 상세 보기");
    action.className = "card-action";
    body.append(meta, element("h4", project.title), tags, element("p", project.summary), action);
    link.append(preview, body);
    card.append(link);
    return card;
  }



  const entry = element("details");
  entry.append(element("summary", project.title));
  const metadata = [project.kind, project.period, project.version].filter(Boolean).join(" · ");
  if (metadata) entry.append(element("p", metadata));
  entry.append(element("p", project.summary));
  for (const [label, value] of [
    ["개인 담당", project.contribution],
    ["기술 스택", project.stack.join(", ")],
    ["검증", project.verification],
  ]) {
    if (value) {
      const row = element("p");
      row.append(element("strong", label + " "), document.createTextNode(value));
      entry.append(row);
    }
  }

  if (project.detailsUrl) {
    const link = element("a", "프로젝트 상세 보기");
    link.href = project.detailsUrl;
    const row = element("p");
    row.append(link);
    entry.append(row);
  }

  if (project.media?.length) {
    const gallery = element("div");
    gallery.className = "gallery";
    for (const media of project.media) {
      const figure = element("figure");
      const asset = element(media.type === "video" ? "video" : "img");
      asset.src = media.src;
      if (asset instanceof HTMLVideoElement) {
        asset.controls = true;
        asset.preload = "none";
        if (media.poster) asset.poster = media.poster;
        if (media.captions) {
          const captions = element("track");
          Object.assign(captions, { kind: "captions", src: media.captions, srclang: "ko", label: "한국어", default: true });
          asset.append(captions);
        }
      } else {
        Object.assign(asset, { alt: media.alt, loading: "lazy", decoding: "async", width: media.width, height: media.height });
      }
      figure.append(asset);
      if (media.caption) figure.append(element("figcaption", media.caption));
      gallery.append(figure);
    }
    entry.append(gallery);
  }
  return entry;
}

function emphasize(grid) {
  for (const track of [...grid.children]) {
    const selected = track.dataset.track === role.value;
    track.classList.toggle("emphasis", selected);
    if (selected) grid.prepend(track);
  }
  if (role.value === "all") grid.prepend(grid.querySelector('[data-track="xr"]'));
}

const technologies = new Set(projects.flatMap(project => project.stack));
for (const technology of [...technologies].sort((a, b) => a.localeCompare(b, "ko"))) {
  stack.add(new Option(technology, technology));
}
stack.disabled = technologies.size === 0;

function update() {
  let count = 0;
  for (const track of trackGrid.children) {
    const id = track.dataset.track;
    const entries = projects.filter(project => project.track === id);
    const visible = entries.filter(project => stack.value === "all" || project.stack.includes(stack.value));
    const categoryMatches = category.value === "all" || category.value === id;
    track.hidden = !categoryMatches || (stack.value !== "all" && visible.length === 0);
    const list = track.querySelector("[data-projects]");
    for (const entry of list.children) {
      entry.hidden = stack.value !== "all" && !entry.projectStack.includes(stack.value);
    }
    track.querySelector("[data-placeholder]").hidden = entries.length > 0;
    if (categoryMatches) count += visible.length;
  }
  emphasize(trackGrid);
  emphasize(engineering);
  results.textContent = count ? `표시 중인 프로젝트 ${count}건` :
    projects.length ? "선택한 조건의 프로젝트가 없습니다." : "등록된 공개 프로젝트가 없습니다.";
}

for (const project of projects) {
  const entry = renderProject(project);
  entry.projectStack = project.stack;
  const track = [...trackGrid.children].find(card => card.dataset.track === project.track);
  track.querySelector("[data-projects]").append(entry);
}
for (const filter of [role, category, stack]) filter.addEventListener("change", update);
document.querySelector("#filters").hidden = false;
update();
